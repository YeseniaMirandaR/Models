const {QuoteModel} = require('./../models/quoteModel')

const QuotesController = {
    showMain: function(req, res) {
        res.render('index');
    },

    renderQuote: function(req, res) {
        QuoteModel
        .find()
        .then(data=>{
            res.render('quotes', { quotes: data });
        });
    },
    
    createQuote: function(request, res) {
        const name = request.body.name;
        const quote = request.body.quote;
        const newQuote = {name, 
        quote, date: new Date()};
            QuoteModel
            .create (newQuote)
            .then(result => {
                request.session.name = result.name;
                request.session.quote = result.quote;
                res.redirect('/quotes');
            })
            .catch(err => {
                console.log("We have an error!", err);
                for (var key in err.errors) {
                    request.flash('quotes', err.errors[key].message);
                }
                res.redirect('/');
            });
    }
}

module.exports = {QuotesController};
