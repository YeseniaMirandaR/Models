const mongoose = require('mongoose');
const quoteSchema = new mongoose.Schema({
    name: {
        type: String,
        required: [true, " Your Name is required "]
    },
    quote: {
        type: String,
        required: [true, " Your Quote is required "]
    },
    date: {
        type: Date,
    }
});

const Quote = mongoose.model('quotes', quoteSchema);

const QuoteModel = {
    create : function( newQuote ){
        return Quote.create( newQuote );
    },
    find : function(){
        return Quote.find()
        }    
};

module.exports = {QuoteModel};